# Chicago Police Department — Crime Data Analytics Capstone

An end-to-end Python data pipeline, analytical reporting suite, and full-stack web application built to analyze Chicago Police Department (CPD) crime data, generate actionable visual insights, and manage the `iucr` dimension table via RESTful CRUD operations.

## Tech Stack
- **Data Analysis & Visualization:** Python, Pandas, NumPy, Matplotlib, Seaborn
- **Database & ORM:** SQLite3 (`chicago_crime.db`), SQLAlchemy 2
- **Backend API:** FastAPI, Uvicorn, Pydantic
- **Frontend UI:** Streamlit

---

## Project Structure

```text
chicago_crime_project/
├── backend/
│   ├── __init__.py
│   ├── database.py               # SQLite3 + SQLAlchemy 2 engine & session
│   ├── models.py                 # SQLAlchemy 2 table models
│   ├── schemas.py                # Pydantic request/response schemas
│   └── main.py                   # FastAPI app (IUCR pipeline + CRUD endpoints)
├── frontend/
│   └── app.py                    # Streamlit UI (Static Dashboard + CRUD tab)
├── .streamlit/
│   └── config.toml               # Soft-grey UI theme configuration
├── usecases/
│   ├── usecase1.py               # UC1: Load, clean, feature engineering & SQLite load
│   ├── usecase2.py               # UC2: Exploratory analysis & visualizations
│   ├── usecase3.py               # UC3: Statistical insights, IQR outliers & correlation
│   └── usecase4.py               # UC4: SQL summary tables, views, Pandas read & charts
├── data/                         # Source CSV datasets
├── outputs/
│   └── charts/                   # Pre-generated static PNG charts (Use Cases 2–4)
├── chicago_crime.db              # Populated SQLite3 database
├── requirements.txt              # Python dependencies
├── Chicago_Crime_Capstone_Report.docx  # Final report with screenshots & insights
└── README.md
```

---

## 1. Setup Instructions

Open a terminal in the `chicago_crime_project` root folder and create a virtual environment:

```bash
python -m venv .venv
```

Activate the virtual environment:
- **Windows (Git Bash):** `source .venv/Scripts/activate`
- **Windows (PowerShell):** `.\.venv\Scripts\Activate.ps1`
- **Windows (CMD):** `.venv\Scripts\activate.bat`
- **macOS / Linux:** `source .venv/bin/activate`

Install the required packages:

```bash
pip install -r requirements.txt
```

---

## 2. Running the Use Case Scripts (Optional — Already Pre-Generated)

The database (`chicago_crime.db`) and all 9 charts in `outputs/charts/` are already generated. To re-run the full data pipeline and regenerate all outputs from scratch, run:

```bash
python usecases/usecase1.py
python usecases/usecase2.py
python usecases/usecase3.py
python usecases/usecase4.py
```

---

## 3. Running the Web Application

Open **two terminals** inside the project root (with `.venv` activated in both):

**Terminal 1 — Start the FastAPI Backend:**
```bash
uvicorn backend.main:app --reload
```
- API Base URL: `http://127.0.0.1:8000`
- Interactive Swagger Docs: `http://127.0.0.1:8000/docs`

**Terminal 2 — Start the Streamlit Frontend:**
```bash
streamlit run frontend/app.py
```
- Web App URL: `http://localhost:8501`

---

## 4. API Endpoints (`backend/main.py`)

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/` | Health check |
| `POST` | `/pipeline/iucr/load` | Reads `data/iucr_codes.csv`, cleans it, and upserts into the `iucr` table |
| `GET` | `/iucr` | List or search IUCR records (`?search=...&limit=100`) |
| `GET` | `/iucr/{iucr_code}` | Fetch a single IUCR record by code |
| `POST` | `/iucr` | Create a new IUCR record |
| `PUT` | `/iucr/{iucr_code}` | Replace an existing IUCR record |
| `PATCH` | `/iucr/{iucr_code}` | Partially update selected fields of an IUCR record |
| `DELETE` | `/iucr/{iucr_code}` | Delete an IUCR record |

---

## 5. Notes on the Dataset
- `data/chicago_crime_dataset.csv` contains one malformed CSV line (21 fields instead of 20), which is safely skipped using `on_bad_lines="skip"`, yielding **496 clean records**.
- All sample records contain date-only timestamps (`00:00`), so hourly counts in Use Case 3 aggregate at Hour `0` and the `hour` correlation row has zero variance.