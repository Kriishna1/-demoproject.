from pathlib import Path
import pandas as pd
import requests
import streamlit as st

# -------------------------------------------------------------------------
# PAGE CONFIG & MODERN SOFT-GREY FIGMA THEME
# -------------------------------------------------------------------------
st.set_page_config(
    page_title="Chicago Crime Analytics | CPD",
    page_icon="🛡️",
    layout="wide",
)

st.markdown(
    """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');

        /* Apply Plus Jakarta Sans globally */
        html, body, [class*="css"], .stApp {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif !important;
            background-color: #ECEFF4;
            color: #1E293B;
        }

        /* Hide default Streamlit top deploy bar clutter for cleaner screenshots */
        header[data-testid="stHeader"] {
            background-color: #ECEFF4;
        }

        .block-container {
            padding-top: 1.75rem;
            padding-bottom: 3rem;
            max-width: 1180px;
        }

        /* Sleek Slate Hero Banner */
        .header-box {
            background: linear-gradient(135deg, #1E293B 0%, #334155 100%);
            border-radius: 16px;
            padding: 1.75rem 2.25rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
        }
        .header-badge {
            display: inline-block;
            background: rgba(255, 255, 255, 0.14);
            color: #E2E8F0;
            font-size: 0.72rem;
            font-weight: 600;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            padding: 0.25rem 0.65rem;
            border-radius: 999px;
            margin-bottom: 0.6rem;
        }
        .header-title {
            font-size: 1.65rem;
            font-weight: 700;
            color: #FFFFFF;
            letter-spacing: -0.02em;
            margin: 0;
        }
        .header-sub {
            font-size: 0.92rem;
            color: #CBD5E1;
            margin-top: 0.35rem;
        }

        /* Elevated White Cards on Soft Grey Canvas */
        [data-testid="stVerticalBlockBorderWrapper"] {
            background-color: #FFFFFF;
            border: 1px solid #DDE3EC !important;
            border-radius: 14px !important;
            padding: 0.5rem 0.75rem;
            box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04);
        }

        /* KPI Cards with subtle top accent */
        .kpi-card {
            background: #FFFFFF;
            border: 1px solid #DDE3EC;
            border-top: 3px solid #2563EB;
            border-radius: 12px;
            padding: 1.15rem 1.3rem;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
        }
        .kpi-label {
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #64748B;
            margin-bottom: 0.35rem;
        }
        .kpi-value {
            font-size: 1.45rem;
            font-weight: 700;
            color: #0F172A;
            letter-spacing: -0.02em;
        }

        /* Section Headings */
        h3 {
            font-size: 1.15rem !important;
            font-weight: 700 !important;
            color: #334155 !important;
            margin-top: 1.25rem !important;
            margin-bottom: 0.75rem !important;
            letter-spacing: -0.01em;
        }

        /* Insight Callout Box */
        .insight-box {
            background: #F4F6FA;
            border-left: 3px solid #2563EB;
            border-radius: 0 8px 8px 0;
            padding: 0.7rem 1rem;
            font-size: 0.88rem;
            line-height: 1.5;
            color: #334155;
            margin-top: 0.6rem;
        }

        /* Modern Pill-Style Tabs */
        .stTabs [data-baseweb="tab-list"] {
            gap: 8px;
            background-color: #E2E8F0;
            padding: 5px;
            border-radius: 12px;
            width: fit-content;
            margin-bottom: 1rem;
        }
        .stTabs [data-baseweb="tab"] {
            border-radius: 8px;
            padding: 0.45rem 1.1rem;
            font-weight: 600;
            font-size: 0.9rem;
            color: #475569;
            border: none !important;
        }
        .stTabs [aria-selected="true"] {
            background-color: #FFFFFF !important;
            color: #0F172A !important;
            box-shadow: 0 1px 4px rgba(15, 23, 42, 0.08);
        }
        .stTabs [data-baseweb="tab-highlight"] {
            display: none;
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# Paths and Backend API URL
BASE_DIR = Path(__file__).resolve().parent.parent
CHARTS_DIR = BASE_DIR / "outputs" / "charts"
API_URL = "http://127.0.0.1:8000"


# Helper function to display a static chart with its insight card
def show_chart_card(title: str, filename: str, insight: str):
    with st.container(border=True):
        st.markdown(f"<div style='font-size:1.05rem; font-weight:700; color:#0F172A; margin-bottom:0.5rem;'>{title}</div>", unsafe_allow_html=True)
        img_path = CHARTS_DIR / filename
        if img_path.exists():
            st.image(str(img_path), use_container_width=True)
        else:
            st.warning(f"Chart not found: {filename}. Run the usecase scripts first.")
        st.markdown(f'<div class="insight-box"><strong>Insight:</strong> {insight}</div>', unsafe_allow_html=True)


# -------------------------------------------------------------------------
# TOP HEADER
# -------------------------------------------------------------------------
st.markdown(
    """
    <div class="header-box">
        <div class="header-badge">Chicago Police Department</div>
        <div class="header-title">Crime Analytics & IUCR Management Portal</div>
        <div class="header-sub">
            Static analytical dashboard and IUCR dimension table pipeline & CRUD operations.
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

# Main Navigation Tabs
tab_dashboard, tab_crud = st.tabs(["📊 Analytics Dashboard", "🛠️ IUCR Pipeline & CRUD"])


# =========================================================================
# TAB 1: STATIC ANALYTICS DASHBOARD (USE CASES 2, 3, AND 4)
# =========================================================================
with tab_dashboard:
    # KPI Summary Row
    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown('<div class="kpi-card"><div class="kpi-label">Clean Records</div><div class="kpi-value">496</div></div>', unsafe_allow_html=True)
    with k2:
        st.markdown('<div class="kpi-card"><div class="kpi-label">Overall Arrest Rate</div><div class="kpi-value">25.00%</div></div>', unsafe_allow_html=True)
    with k3:
        st.markdown('<div class="kpi-card"><div class="kpi-label">Top Crime Type</div><div class="kpi-value">THEFT (21.2%)</div></div>', unsafe_allow_html=True)
    with k4:
        st.markdown('<div class="kpi-card"><div class="kpi-label">Top Community</div><div class="kpi-value">Austin (34)</div></div>', unsafe_allow_html=True)

    st.write("")  # Clean vertical spacing

    # --- Section: Use Case 2 ---
    st.markdown("### Use Case 2 — Exploratory Analysis & Visualization")
    col1, col2 = st.columns(2)
    with col1:
        show_chart_card(
            "Crime Trend Over Years",
            "uc2_crime_trend_years.png",
            "Recorded incidents spike in 2016 (488 of 496 rows) because the sample dataset is heavily concentrated in May 2016.",
        )
    with col2:
        show_chart_card(
            "Top 10 Crime Categories",
            "uc2_top10_categories.png",
            "THEFT (105 crimes, 21.17%) and BATTERY (85 crimes, 17.14%) together account for nearly 40% of all reported incidents.",
        )

    col3, col4 = st.columns(2)
    with col3:
        show_chart_card(
            "Crime Heatmap: Month vs Day of Week",
            "uc2_heatmap_month_day.png",
            "Month 5 (May) has the highest crime frequency (445 incidents), peaking sharply on Tuesday (146) and Wednesday (297).",
        )
    with col4:
        show_chart_card(
            "Top 10 Community Areas",
            "uc2_top10_communities.png",
            "Austin leads with 34 incidents, followed by Near North Side (20) and Humboldt Park (20)—key candidates for focused patrols.",
        )

    # --- Section: Use Case 3 ---
    st.markdown("### Use Case 3 — Statistical Insights & Pattern Detection")
    col5, col6 = st.columns(2)
    with col5:
        show_chart_card(
            "Crime Intensity by Hour of Day",
            "uc3_crimes_by_hour.png",
            "Hourly distribution helps CPD align shift handovers and patrol density with peak reporting hours.",
        )
    with col6:
        show_chart_card(
            "Community Area Outlier Detection (Box Plot)",
            "uc3_community_boxplot.png",
            "Using the IQR method, high-volume areas like Austin stand out above the upper threshold as statistical outliers.",
        )

    show_chart_card(
        "Numeric Feature Cross-Correlation Matrix",
        "uc3_correlation_heatmap.png",
        "Shows linear relationships across year, month, hour, arrest, domestic status, and geographic codes (district, ward, community).",
    )

    # --- Section: Use Case 4 ---
    st.markdown("### Use Case 4 — SQL Views & Database Reporting")
    col7, col8 = st.columns(2)
    with col7:
        show_chart_card(
            "SQL View: Crimes vs Arrests per Year",
            "uc4_sql_yearly.png",
            "Extracted directly from vw_crime_yearly. Overall arrest rate is 25.00% (24.39% in 2016).",
        )
    with col8:
        show_chart_card(
            "SQL View: Top 5 Crime Categories",
            "uc4_sql_top5_categories.png",
            "Extracted from vw_crime_by_category: Theft, Battery, Criminal Damage, Other Offense, and Deceptive Practice.",
        )


# =========================================================================
# TAB 2: IUCR DIMENSION TABLE PIPELINE & CRUD (CONNECTED TO FASTAPI)
# =========================================================================
with tab_crud:
    # --- Section 1: Data Pipeline ---
    with st.container(border=True):
        st.subheader("1. Dimension Table Data Pipeline (IUCR)")
        st.caption("Reads data/iucr_codes.csv, cleans column names and whitespace, and loads all rows into SQLite3 via FastAPI.")

        if st.button("Run IUCR CSV → SQLite3 Pipeline", type="primary"):
            try:
                res = requests.post(f"{API_URL}/pipeline/iucr/load", timeout=10)
                if res.status_code == 200:
                    data = res.json()
                    st.success(
                        f"{data['message']} — Inserted: {data['inserted']}, Updated: {data['updated']} (Total CSV rows: {data['total_in_csv']})"
                    )
                else:
                    st.error(f"Pipeline failed ({res.status_code}): {res.text}")
            except requests.exceptions.ConnectionError:
                st.error("Cannot connect to FastAPI. Make sure `uvicorn backend.main:app --reload` is running.")

    st.write("")

    # --- Section 2: View & Search IUCR Table ---
    with st.container(border=True):
        st.subheader("2. Browse IUCR Dimension Table (GET)")
        search_term = st.text_input("Search by IUCR Code, Primary Type, or Description", placeholder="e.g., 110 or THEFT")

        try:
            params = {"limit": 100}
            if search_term.strip():
                params["search"] = search_term.strip()
            res = requests.get(f"{API_URL}/iucr", params=params, timeout=5)
            if res.status_code == 200:
                records = res.json()
                if records:
                    st.dataframe(pd.DataFrame(records), use_container_width=True, hide_index=True)
                else:
                    st.info("No matching IUCR records found.")
            else:
                st.error(f"Error fetching records: {res.text}")
        except requests.exceptions.ConnectionError:
            st.warning("FastAPI backend is not reachable at http://127.0.0.1:8000.")

    st.write("")

    # --- Section 3: CRUD Operations (POST, PUT, PATCH, DELETE) ---
    with st.container(border=True):
        st.subheader("3. Manage IUCR Records (CRUD)")
        t_post, t_put, t_patch, t_delete = st.tabs(["Create (POST)", "Replace (PUT)", "Partial Update (PATCH)", "Delete (DELETE)"])

        # CREATE (POST)
        with t_post:
            with st.form("create_iucr_form"):
                c1, c2 = st.columns(2)
                new_code = c1.text_input("IUCR Code *", placeholder="e.g., 9999")
                new_index = c2.text_input("Index Code", placeholder="e.g., I or N")
                new_type = st.text_input("Primary Type *", placeholder="e.g., CYBER CRIME")
                new_desc = st.text_input("Description *", placeholder="e.g., ONLINE PHISHING")
                submitted_post = st.form_submit_button("Create Record (POST)", type="primary")

                if submitted_post:
                    payload = {
                        "iucr_code": new_code,
                        "primary_type": new_type,
                        "description": new_desc,
                        "index_code": new_index or None,
                    }
                    res = requests.post(f"{API_URL}/iucr", json=payload, timeout=5)
                    if res.status_code == 201:
                        st.success(f"Created IUCR record: {res.json()}")
                    else:
                        st.error(f"Error ({res.status_code}): {res.json().get('detail', res.text)}")

        # REPLACE (PUT)
        with t_put:
            with st.form("put_iucr_form"):
                c1, c2 = st.columns(2)
                put_code = c1.text_input("Existing IUCR Code *", placeholder="e.g., 9999")
                put_index = c2.text_input("New Index Code", placeholder="e.g., N")
                put_type = st.text_input("New Primary Type *", placeholder="e.g., FRAUD")
                put_desc = st.text_input("New Description *", placeholder="e.g., IDENTITY THEFT")
                submitted_put = st.form_submit_button("Replace Record (PUT)", type="primary")

                if submitted_put:
                    payload = {
                        "primary_type": put_type,
                        "description": put_desc,
                        "index_code": put_index or None,
                    }
                    res = requests.put(f"{API_URL}/iucr/{put_code.strip()}", json=payload, timeout=5)
                    if res.status_code == 200:
                        st.success(f"Replaced IUCR record: {res.json()}")
                    else:
                        st.error(f"Error ({res.status_code}): {res.json().get('detail', res.text)}")

        # PARTIAL UPDATE (PATCH)
        with t_patch:
            with st.form("patch_iucr_form"):
                patch_code = st.text_input("Existing IUCR Code *", placeholder="e.g., 9999")
                patch_type = st.text_input("Update Primary Type (optional)")
                patch_desc = st.text_input("Update Description (optional)")
                patch_index = st.text_input("Update Index Code (optional)")
                submitted_patch = st.form_submit_button("Update Selected Fields (PATCH)", type="primary")

                if submitted_patch:
                    payload = {}
                    if patch_type.strip():
                        payload["primary_type"] = patch_type.strip()
                    if patch_desc.strip():
                        payload["description"] = patch_desc.strip()
                    if patch_index.strip():
                        payload["index_code"] = patch_index.strip()

                    res = requests.patch(f"{API_URL}/iucr/{patch_code.strip()}", json=payload, timeout=5)
                    if res.status_code == 200:
                        st.success(f"Patched IUCR record: {res.json()}")
                    else:
                        st.error(f"Error ({res.status_code}): {res.json().get('detail', res.text)}")

        # DELETE
        with t_delete:
            with st.form("delete_iucr_form"):
                del_code = st.text_input("IUCR Code to Delete *", placeholder="e.g., 9999")
                submitted_delete = st.form_submit_button("Delete Record (DELETE)", type="primary")

                if submitted_delete:
                    res = requests.delete(f"{API_URL}/iucr/{del_code.strip()}", timeout=5)
                    if res.status_code == 200:
                        st.success(res.json()["message"])
                    else:
                        st.error(f"Error ({res.status_code}): {res.json().get('detail', res.text)}")