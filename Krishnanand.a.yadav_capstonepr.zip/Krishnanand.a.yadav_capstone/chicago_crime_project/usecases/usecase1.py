import pandas as pd
import numpy as np
from sqlalchemy import create_engine

# Connect to the SQLite3 database in the project root folder
engine = create_engine("sqlite:///chicago_crime.db")

print("========== USE CASE 1: LOAD AND CLEAN CHICAGO CRIME DATA ==========\n")

# -------------------------------------------------------------------------
# TASK 1: Load the dataset (CSV) into a Pandas DataFrame
# -------------------------------------------------------------------------
# df = pd.read_csv("data/chicago_crime_dataset.csv", low_memory=False)
df = pd.read_csv("data/chicago_crime_dataset.csv", low_memory=False, on_bad_lines="skip")

# Inspect the first 10 rows
print("--- First 10 Rows ---")
print(df.head(10))

# Show schema and data types
print("\n--- Schema and Data Types ---")
print(df.dtypes)

# How many columns and rows are there?
rows, cols = df.shape
print(f"\nTotal Rows: {rows}")
print(f"Total Columns: {cols}")

# -------------------------------------------------------------------------
# TASK 4 (Checked before cleaning): Use NumPy to calculate % of missing values
# -------------------------------------------------------------------------
print("\n--- Percentage of Missing Values per Column (Using NumPy) ---")
for col in df.columns:
    # np.mean on a True/False array gives the fraction of missing values
    missing_percent = np.mean(df[col].isna().to_numpy()) * 100
    print(f"{col}: {missing_percent:.2f}%")

# -------------------------------------------------------------------------
# TASK 2: Clean the dataset
# -------------------------------------------------------------------------
print("\n--- Cleaning the Dataset ---")

# 1. Convert the date column into datetime format
before_dates = df["date"].notna().sum()
df["date"] = pd.to_datetime(df["date"], errors="coerce")
bad_dates = before_dates - df["date"].notna().sum()

# 2. Identify and handle missing values for key fields
# Drop rows where critical fields (id, case_number, date) are missing
df = df.dropna(subset=["id", "case_number", "date"]).copy()

# Fill missing text fields with "UNKNOWN"
df["location_desc"] = df["location_desc"].fillna("UNKNOWN")
df["block"] = df["block"].fillna("UNKNOWN")
df["iucr_code"] = df["iucr_code"].fillna("UNKNOWN")
df["fbi_code"] = df["fbi_code"].fillna("UNKNOWN")

# 3. Standardize categorical fields (strip whitespace and convert to UPPERCASE)
text_columns = ["case_number", "block", "iucr_code", "location_desc", "fbi_code"]
for col in text_columns:
    df[col] = df[col].astype(str).str.strip().str.upper()

# Make sure arrest and domestic are clean True/False values
df["arrest"] = df["arrest"].astype(str).str.strip().str.upper() == "TRUE"
df["domestic"] = df["domestic"].astype(str).str.strip().str.upper() == "TRUE"

# Remove duplicate rows based on id
df = df.drop_duplicates(subset=["id"])
print(f"Cleaning complete. Total clean rows: {len(df)}")

# -------------------------------------------------------------------------
# TASK 3: Generate new features (Year, Month, DayOfWeek)
# -------------------------------------------------------------------------
df["year"] = df["date"].dt.year
df["month"] = df["date"].dt.month
df["day_of_week"] = df["date"].dt.day_name()

print("\n--- Sample of New Date Features ---")
print(df[["date", "year", "month", "day_of_week"]].head(5))

# -------------------------------------------------------------------------
# TASK 5: Insert cleaned data into SQLite3 using SQLAlchemy
# -------------------------------------------------------------------------
print("\n--- Saving Data to SQLite3 (chicago_crime.db) ---")

# Save the main cleaned crime table
df.to_sql("chicago_crime", con=engine, if_exists="replace", index=False, chunksize=5000)
print("Saved 'chicago_crime' table.")

# Also load the IUCR lookup table so we have primary_type for crime categories
iucr_df = pd.read_csv("data/iucr_codes.csv", dtype=str)
iucr_df.columns = [c.strip() for c in iucr_df.columns]  # removes trailing space in 'PRIMARY_TYPE '
iucr_df = iucr_df.rename(columns={
    "IUCR": "iucr_code",
    "PRIMARY_TYPE": "primary_type",
    "DESCRIPTION": "description",
    "INDEX CODE": "index_code"
})
for col in iucr_df.columns:
    iucr_df[col] = iucr_df[col].fillna("").str.strip().str.upper()
iucr_df.to_sql("iucr", con=engine, if_exists="replace", index=False)
print("Saved 'iucr' lookup table.")

# Also load the Community Area lookup table for community names
comm_df = pd.read_csv("data/chicago_city_community.csv")
comm_df.columns = [c.strip().lower() for c in comm_df.columns]
comm_df["community_name"] = comm_df["community_name"].astype(str).str.strip()
comm_df.to_sql("city_community", con=engine, if_exists="replace", index=False)
print("Saved 'city_community' lookup table.")

# -------------------------------------------------------------------------
# USE CASE 1 QUESTIONS
# -------------------------------------------------------------------------
print("\n========== USE CASE 1 QUESTIONS ==========")

# Question 1: How many unique crime types exist in the dataset?
merged = df.merge(iucr_df[["iucr_code", "primary_type"]], on="iucr_code", how="left")
print("Q1. Unique IUCR codes in crime dataset:", df["iucr_code"].nunique())
print("Q1. Unique Primary Crime Types (joined with IUCR):", merged["primary_type"].nunique())

# Question 2: Are there anomalies in date formats or obvious outliers?
print("Q2. Invalid/unreadable dates found:", bad_dates)
print("Q2. Earliest date:", df["date"].min())
print("Q2. Latest date:", df["date"].max())
print("Q2. Crime count by year (to spot any outlier years):")
print(df["year"].value_counts().sort_index())