import os
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Make sure the charts folder exists
os.makedirs("outputs/charts", exist_ok=True)

# Connect to the SQLite3 database using Python's built-in sqlite3 connector
conn = sqlite3.connect("chicago_crime.db")
cursor = conn.cursor()

print("========== USE CASE 4: SQL REPORTING & INTEGRATION ==========\n")

# -------------------------------------------------------------------------
# TASK 1: Design & Populate Summary Tables
# -------------------------------------------------------------------------
print("--- Task 1: Creating and Populating Summary Tables ---")

# 1a. Create yearly summary table
cursor.execute("DROP TABLE IF EXISTS summary_crime_yearly")
cursor.execute("""
    CREATE TABLE summary_crime_yearly (
        year INTEGER PRIMARY KEY,
        total_crimes INTEGER,
        total_arrests INTEGER
    )
""")

# Populate yearly summary table from chicago_crime
cursor.execute("""
    INSERT INTO summary_crime_yearly (year, total_crimes, total_arrests)
    SELECT
        year,
        COUNT(*) AS total_crimes,
        SUM(CASE WHEN arrest = 1 THEN 1 ELSE 0 END) AS total_arrests
    FROM chicago_crime
    GROUP BY year
    ORDER BY year
""")

# 1b. Create category summary table
cursor.execute("DROP TABLE IF EXISTS summary_crime_by_category")
cursor.execute("""
    CREATE TABLE summary_crime_by_category (
        primary_type TEXT PRIMARY KEY,
        crime_count INTEGER,
        percentage REAL
    )
""")

# Populate category summary table by joining chicago_crime with iucr
cursor.execute("""
    INSERT INTO summary_crime_by_category (primary_type, crime_count, percentage)
    SELECT
        COALESCE(i.primary_type, 'UNKNOWN') AS primary_type,
        COUNT(*) AS crime_count,
        ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM chicago_crime), 2) AS percentage
    FROM chicago_crime c
    LEFT JOIN iucr i ON c.iucr_code = i.iucr_code
    GROUP BY COALESCE(i.primary_type, 'UNKNOWN')
    ORDER BY crime_count DESC
""")

conn.commit()
print("Summary tables 'summary_crime_yearly' and 'summary_crime_by_category' created and populated.\n")

# -------------------------------------------------------------------------
# TASK 2: SQL Queries
# -------------------------------------------------------------------------
print("--- Task 2: SQL Query Results ---")

# Query 1: Crime count per year
q_yearly = """
    SELECT year, COUNT(*) AS crime_count
    FROM chicago_crime
    GROUP BY year
    ORDER BY year
"""
print("\n1. Crime Count per Year:")
print(pd.read_sql(q_yearly, conn).to_string(index=False))

# Query 2: Top 5 crime types and their percentages
q_top5 = """
    SELECT
        COALESCE(i.primary_type, 'UNKNOWN') AS primary_type,
        COUNT(*) AS crime_count,
        ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM chicago_crime), 2) AS percentage
    FROM chicago_crime c
    LEFT JOIN iucr i ON c.iucr_code = i.iucr_code
    GROUP BY COALESCE(i.primary_type, 'UNKNOWN')
    ORDER BY crime_count DESC
    LIMIT 5
"""
print("\n2. Top 5 Crime Types and Percentages:")
print(pd.read_sql(q_top5, conn).to_string(index=False))

# Query 3: Arrest count per year
q_arrests = """
    SELECT
        year,
        SUM(CASE WHEN arrest = 1 THEN 1 ELSE 0 END) AS arrest_count
    FROM chicago_crime
    GROUP BY year
    ORDER BY year
"""
print("\n3. Arrest Count per Year:")
print(pd.read_sql(q_arrests, conn).to_string(index=False))

# -------------------------------------------------------------------------
# TASK 3: Database Stored Views
# -------------------------------------------------------------------------
print("\n--- Task 3: Creating Database Views ---")

# View 1: vw_crime_yearly
cursor.execute("DROP VIEW IF EXISTS vw_crime_yearly")
cursor.execute("""
    CREATE VIEW vw_crime_yearly AS
    SELECT
        year,
        COUNT(*) AS total_crimes,
        SUM(CASE WHEN arrest = 1 THEN 1 ELSE 0 END) AS total_arrests
    FROM chicago_crime
    GROUP BY year
    ORDER BY year
""")

# View 2: vw_crime_by_category
cursor.execute("DROP VIEW IF EXISTS vw_crime_by_category")
cursor.execute("""
    CREATE VIEW vw_crime_by_category AS
    SELECT
        COALESCE(i.primary_type, 'UNKNOWN') AS primary_type,
        COUNT(*) AS crime_count,
        ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM chicago_crime), 2) AS percentage
    FROM chicago_crime c
    LEFT JOIN iucr i ON c.iucr_code = i.iucr_code
    GROUP BY COALESCE(i.primary_type, 'UNKNOWN')
    ORDER BY crime_count DESC
""")

conn.commit()
print("Views 'vw_crime_yearly' and 'vw_crime_by_category' created successfully.\n")

# -------------------------------------------------------------------------
# TASK 4: Pandas Integration (Read views into DataFrames)
# -------------------------------------------------------------------------
print("--- Task 4: Reading Views into Pandas DataFrames ---")

df_yearly = pd.read_sql("SELECT * FROM vw_crime_yearly", conn)
df_category = pd.read_sql("SELECT * FROM vw_crime_by_category", conn)

print("\nDataFrame from vw_crime_yearly:")
print(df_yearly.to_string(index=False))

print("\nTop 5 rows from vw_crime_by_category:")
print(df_category.head(5).to_string(index=False))

# -------------------------------------------------------------------------
# TASK 5: Visualization from SQL Data
# -------------------------------------------------------------------------
print("\n--- Task 5: Plotting SQL-Extracted Data ---")
sns.set_theme(style="whitegrid")

# Chart 1: Crimes vs Arrests per Year (from vw_crime_yearly)
plt.figure(figsize=(8, 4))
plt.plot(df_yearly["year"], df_yearly["total_crimes"], marker="o", label="Total Crimes", color="#1f77b4")
plt.plot(df_yearly["year"], df_yearly["total_arrests"], marker="s", label="Total Arrests", color="#d62728")
plt.title("SQL View: Total Crimes vs Arrests per Year")
plt.xlabel("Year")
plt.ylabel("Count")
plt.xticks(df_yearly["year"])
plt.legend()
plt.tight_layout()
plt.savefig("outputs/charts/uc4_sql_yearly.png", dpi=150)
plt.close()

# Chart 2: Top 5 Crime Categories (from vw_crime_by_category)
top5_df = df_category.head(5)
plt.figure(figsize=(9, 4))
sns.barplot(data=top5_df, x="crime_count", y="primary_type", color="#457b9d")
plt.title("SQL View: Top 5 Crime Categories")
plt.xlabel("Crime Count")
plt.ylabel("Primary Type")
plt.tight_layout()
plt.savefig("outputs/charts/uc4_sql_top5_categories.png", dpi=150)
plt.close()

# Close database connection
conn.close()
print("All Use Case 4 charts saved in outputs/charts/ successfully!")