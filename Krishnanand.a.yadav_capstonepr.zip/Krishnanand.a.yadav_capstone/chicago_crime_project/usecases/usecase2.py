import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine

# Make sure the charts folder exists
os.makedirs("outputs/charts", exist_ok=True)

# Connect to the SQLite3 database created in Use Case 1
engine = create_engine("sqlite:///chicago_crime.db")

print("========== USE CASE 2: EXPLORATORY ANALYSIS & VISUALIZATION ==========\n")

# Load cleaned crime data and lookup tables from SQLite3
df = pd.read_sql("SELECT * FROM chicago_crime", con=engine)
iucr_df = pd.read_sql("SELECT iucr_code, primary_type FROM iucr", con=engine)
comm_df = pd.read_sql("SELECT community_code, community_name FROM city_community", con=engine)

# Join primary_type and community_name so charts show readable names
df = df.merge(iucr_df, on="iucr_code", how="left")
df = df.merge(comm_df, on="community_code", how="left")
df["primary_type"] = df["primary_type"].fillna("UNKNOWN")
df["community_name"] = df["community_name"].fillna("UNKNOWN")

# Set a clean visual style for all charts
sns.set_theme(style="whitegrid")

# -------------------------------------------------------------------------
# TASK 1: Crime Trend Over Years
# -------------------------------------------------------------------------
print("--- Task 1: Crime Trend Over Years ---")
crimes_per_year = df.groupby("year").size()
print(crimes_per_year)

plt.figure(figsize=(8, 4))
crimes_per_year.plot(kind="line", marker="o", linewidth=2, color="#1f77b4")
plt.title("Total Number of Crimes per Year")
plt.xlabel("Year")
plt.ylabel("Number of Crimes")
plt.xticks(crimes_per_year.index)
plt.tight_layout()
plt.savefig("outputs/charts/uc2_crime_trend_years.png", dpi=150)
plt.close()

print("Visual Interpretation: Recorded crimes rise sharply in 2016 because the sample dataset is heavily concentrated in May 2016 (488 of 496 rows).\n")

# -------------------------------------------------------------------------
# TASK 2: Crime Distribution by Category (Top 10 Primary Types)
# -------------------------------------------------------------------------
print("--- Task 2: Top 10 Crime Categories (Counts & Percentages) ---")
cat_counts = df["primary_type"].value_counts().head(10)
cat_pct = (cat_counts / len(df) * 100).round(2)

top10_categories = pd.DataFrame({
    "Count": cat_counts,
    "Percentage (%)": cat_pct
})
print(top10_categories)

plt.figure(figsize=(10, 5))
sns.barplot(x=cat_counts.values, y=cat_counts.index, color="#2a9d8f")
plt.title("Top 10 Crime Categories (Primary Type)")
plt.xlabel("Number of Crimes")
plt.ylabel("Crime Category")
plt.tight_layout()
plt.savefig("outputs/charts/uc2_top10_categories.png", dpi=150)
plt.close()

# -------------------------------------------------------------------------
# TASK 3: Arrests and Crime Outcomes
# -------------------------------------------------------------------------
print("\n--- Task 3: Arrests and Crime Outcomes ---")
# Ensure arrest is numeric/boolean (0 or 1) before taking the mean
arrest_rate = df["arrest"].astype(bool).mean() * 100
print(f"Overall Arrest Rate: {arrest_rate:.2f}%")

# Also check arrest rate by year for Question 2
arrest_by_year = (df.groupby("year")["arrest"].mean() * 100).round(2)
print("\nArrest Rate (%) by Year:")
print(arrest_by_year)

# -------------------------------------------------------------------------
# TASK 4: Heatmap of Crime by Month and Day of Week
# -------------------------------------------------------------------------
print("\n--- Task 4: Heatmap of Crime by Month and Day of Week ---")
day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

# Create pivot table: rows = Month, columns = DayOfWeek
pivot_table = pd.pivot_table(
    df,
    index="month",
    columns="day_of_week",
    values="id",
    aggfunc="count",
    fill_value=0
)
# Reorder columns to Monday -> Sunday (only keeping days present in data)
pivot_table = pivot_table.reindex(columns=[d for d in day_order if d in pivot_table.columns])
print(pivot_table)

plt.figure(figsize=(9, 4))
sns.heatmap(pivot_table, annot=True, fmt="d", cmap="YlOrRd")
plt.title("Crime Frequency Heatmap: Month vs Day of Week")
plt.xlabel("Day of Week")
plt.ylabel("Month")
plt.tight_layout()
plt.savefig("outputs/charts/uc2_heatmap_month_day.png", dpi=150)
plt.close()

# -------------------------------------------------------------------------
# TASK 5: Top 10 Community Areas
# -------------------------------------------------------------------------
print("\n--- Task 5: Top 10 Community Areas with Highest Crime Counts ---")
top10_comm = df["community_name"].value_counts().head(10)
print(top10_comm)

plt.figure(figsize=(10, 5))
sns.barplot(x=top10_comm.values, y=top10_comm.index, color="#e76f51")
plt.title("Top 10 Community Areas by Crime Count")
plt.xlabel("Number of Crimes")
plt.ylabel("Community Area")
plt.tight_layout()
plt.savefig("outputs/charts/uc2_top10_communities.png", dpi=150)
plt.close()

# -------------------------------------------------------------------------
# USE CASE 2 QUESTIONS
# -------------------------------------------------------------------------
print("\n========== USE CASE 2 QUESTIONS ==========")

# Question 1: Which crime category is most frequent?
most_freq_cat = cat_counts.index[0]
most_freq_count = cat_counts.iloc[0]
print(f"Q1. Most frequent crime category: {most_freq_cat} ({most_freq_count} crimes, {cat_pct.iloc[0]}%)")

# Question 2: Is the arrest rate consistent across different years?
print("Q2. Arrest rate by year (%):")
for yr, rate in arrest_by_year.items():
    print(f"    {yr}: {rate:.2f}%")
print("    Insight: Not consistent—earlier years (2012-2015) have very few sample rows (1-4), causing extreme 0% or 100% swings compared to 2016.")

# Question 3: Which month has the highest crime frequency?
month_counts = df["month"].value_counts()
top_month = month_counts.index[0]
top_month_count = month_counts.iloc[0]
print(f"Q3. Month with highest crime frequency: Month {top_month} ({top_month_count} crimes)")

print("\nAll Use Case 2 charts saved in outputs/charts/ successfully!")