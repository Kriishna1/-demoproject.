import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine

# Make sure the charts folder exists
os.makedirs("outputs/charts", exist_ok=True)

# Connect to the SQLite3 database
engine = create_engine("sqlite:///chicago_crime.db")

print("========== USE CASE 3: STATISTICAL INSIGHTS & PATTERN DETECTION ==========\n")

# Load cleaned crime data and community names from SQLite3
df = pd.read_sql("SELECT * FROM chicago_crime", con=engine)
comm_df = pd.read_sql("SELECT community_code, community_name FROM city_community", con=engine)

# Convert date back to datetime so we can extract the Hour
df["date"] = pd.to_datetime(df["date"], errors="coerce")

# Join community names for clearer outlier reporting
df = df.merge(comm_df, on="community_code", how="left")
df["community_name"] = df["community_name"].fillna("UNKNOWN")

sns.set_theme(style="whitegrid")

# -------------------------------------------------------------------------
# TASK 1: Crime Intensity by Time (Hourly Distribution)
# -------------------------------------------------------------------------
print("--- Task 1: Crime Intensity by Hour of Day ---")

# Extract Hour (0 to 23) from the date column
df["Hour"] = df["date"].dt.hour

# Count crimes for each hour
crimes_by_hour = df.groupby("Hour").size()
print(crimes_by_hour)

# Line plot of crimes per hour of day
plt.figure(figsize=(9, 4))
crimes_by_hour.plot(kind="line", marker="o", linewidth=2, color="#264653")
plt.title("Crime Intensity by Hour of Day")
plt.xlabel("Hour of Day (0–23)")
plt.ylabel("Number of Crimes")
plt.xticks(range(0, 24))
plt.tight_layout()
plt.savefig("outputs/charts/uc3_crimes_by_hour.png", dpi=150)
plt.close()

# -------------------------------------------------------------------------
# TASK 2: Community Area Clusters Using NumPy (Mean & IQR Outliers)
# -------------------------------------------------------------------------
print("\n--- Task 2: Community Area Clusters & Outliers (NumPy + IQR) ---")

# Count total crimes per community area
comm_counts = df.groupby("community_name").size().reset_index(name="crime_count")
counts_array = comm_counts["crime_count"].to_numpy()

# Use NumPy to compute mean, Q1, Q3, and IQR
mean_crimes = np.mean(counts_array)
q1 = np.percentile(counts_array, 25)
q3 = np.percentile(counts_array, 75)
iqr = q3 - q1
upper_bound = q3 + 1.5 * iqr
lower_bound = q1 - 1.5 * iqr

print(f"Mean crimes per community area (NumPy): {mean_crimes:.2f}")
print(f"Q1 (25th percentile): {q1:.2f}")
print(f"Q3 (75th percentile): {q3:.2f}")
print(f"IQR (Q3 - Q1): {iqr:.2f}")
print(f"Upper Outlier Threshold (Q3 + 1.5 * IQR): {upper_bound:.2f}")

# List extreme outlier community areas
outliers = comm_counts[
    (comm_counts["crime_count"] > upper_bound) | (comm_counts["crime_count"] < lower_bound)
].sort_values(by="crime_count", ascending=False)

print("\nExtreme Outlier Community Areas (IQR Method):")
if outliers.empty:
    print("No extreme outliers found.")
else:
    print(outliers.to_string(index=False))

# Box plot to visually identify outliers
plt.figure(figsize=(8, 4))
sns.boxplot(x=comm_counts["crime_count"], color="#f4a261")
plt.title("Distribution of Crime Counts Across Community Areas (Outlier Detection)")
plt.xlabel("Crime Count per Community Area")
plt.tight_layout()
plt.savefig("outputs/charts/uc3_community_boxplot.png", dpi=150)
plt.close()

# -------------------------------------------------------------------------
# TASK 3: Crime Cross-Correlation
# -------------------------------------------------------------------------
print("\n--- Task 3: Correlation Matrix of Numeric Features ---")

# Convert boolean columns (arrest, domestic) to 0/1 so they can be included in .corr()
corr_df = pd.DataFrame({
    "year": df["year"],
    "month": df["month"],
    "hour": df["Hour"],
    "arrest": df["arrest"].astype(int),
    "domestic": df["domestic"].astype(int),
    "district_code": df["district_code"],
    "ward_no": df["ward_no"],
    "community_code": df["community_code"],
})

corr_matrix = corr_df.corr().round(2)
print(corr_matrix)

# Visualize correlation matrix with a heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", vmin=-1, vmax=1, fmt=".2f")
plt.title("Correlation Matrix of Numeric Crime Features")
plt.tight_layout()
plt.savefig("outputs/charts/uc3_correlation_heatmap.png", dpi=150)
plt.close()

print("\nAll Use Case 3 charts saved in outputs/charts/ successfully!")