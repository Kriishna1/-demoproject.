from pathlib import Path
from typing import List, Optional
import pandas as pd
from fastapi import Depends, FastAPI, HTTPException, Query, status
from sqlalchemy.orm import Session

from backend.database import BASE_DIR, Base, engine, get_db
from backend.models import IUCR
from backend.schemas import IUCRCreate, IUCRPatch, IUCRResponse, IUCRUpdate

# Create tables if they do not exist yet
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Chicago Police Department Crime Analytics API",
    description="Data pipeline & CRUD API for the IUCR dimension table (SQLite3 + SQLAlchemy 2).",
    version="1.0.0",
)


@app.get("/")
def health_check():
    return {"status": "ok", "message": "Chicago Crime API is running"}


# ---------- DATA PIPELINE: LOAD DIMENSION TABLE (IUCR) ----------
@app.post("/pipeline/iucr/load")
def load_iucr_pipeline(db: Session = Depends(get_db)):
    """Reads data/iucr_codes.csv, cleans it, and upserts all rows into the iucr table."""
    csv_path: Path = BASE_DIR / "data" / "iucr_codes.csv"
    if not csv_path.exists():
        raise HTTPException(status_code=404, detail=f"CSV not found at {csv_path}")

    df = pd.read_csv(csv_path, dtype=str)
    # Strip trailing/leading spaces from column names (fixes 'PRIMARY_TYPE ')
    df.columns = [col.strip() for col in df.columns]

    df = df.rename(
        columns={
            "IUCR": "iucr_code",
            "PRIMARY_TYPE": "primary_type",
            "DESCRIPTION": "description",
            "INDEX CODE": "index_code",
        }
    )

    for col in ["iucr_code", "primary_type", "description", "index_code"]:
        if col in df.columns:
            df[col] = df[col].fillna("").str.strip()

    df = df[df["iucr_code"] != ""].drop_duplicates(subset=["iucr_code"])

    inserted, updated = 0, 0
    for row in df.to_dict(orient="records"):
        existing = db.get(IUCR, row["iucr_code"])
        if existing:
            existing.primary_type = row["primary_type"].upper()
            existing.description = row["description"].upper()
            existing.index_code = row["index_code"].upper() or None
            updated += 1
        else:
            db.add(
                IUCR(
                    iucr_code=row["iucr_code"],
                    primary_type=row["primary_type"].upper(),
                    description=row["description"].upper(),
                    index_code=row["index_code"].upper() or None,
                )
            )
            inserted += 1

    db.commit()
    return {
        "message": "IUCR dimension table loaded successfully",
        "inserted": inserted,
        "updated": updated,
        "total_in_csv": len(df),
    }


# ---------- CRUD ENDPOINTS FOR IUCR DIMENSION TABLE ----------
@app.get("/iucr", response_model=List[IUCRResponse])
def list_iucr(
    search: Optional[str] = Query(default=None, description="Filter by code or primary type"),
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    query = db.query(IUCR)
    if search:
        pattern = f"%{search.strip()}%"
        query = query.filter(
            (IUCR.iucr_code.ilike(pattern))
            | (IUCR.primary_type.ilike(pattern))
            | (IUCR.description.ilike(pattern))
        )
    return query.order_by(IUCR.iucr_code).limit(limit).all()


@app.get("/iucr/{iucr_code}", response_model=IUCRResponse)
def get_iucr(iucr_code: str, db: Session = Depends(get_db)):
    record = db.get(IUCR, iucr_code.strip())
    if not record:
        raise HTTPException(status_code=404, detail=f"IUCR code '{iucr_code}' not found")
    return record


@app.post("/iucr", response_model=IUCRResponse, status_code=status.HTTP_201_CREATED)
def create_iucr(payload: IUCRCreate, db: Session = Depends(get_db)):
    code = payload.iucr_code.strip()
    if db.get(IUCR, code):
        raise HTTPException(status_code=409, detail=f"IUCR code '{code}' already exists")

    record = IUCR(
        iucr_code=code,
        primary_type=payload.primary_type.strip().upper(),
        description=payload.description.strip().upper(),
        index_code=payload.index_code.strip().upper() if payload.index_code else None,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@app.put("/iucr/{iucr_code}", response_model=IUCRResponse)
def replace_iucr(iucr_code: str, payload: IUCRUpdate, db: Session = Depends(get_db)):
    record = db.get(IUCR, iucr_code.strip())
    if not record:
        raise HTTPException(status_code=404, detail=f"IUCR code '{iucr_code}' not found")

    record.primary_type = payload.primary_type.strip().upper()
    record.description = payload.description.strip().upper()
    record.index_code = payload.index_code.strip().upper() if payload.index_code else None
    db.commit()
    db.refresh(record)
    return record


@app.patch("/iucr/{iucr_code}", response_model=IUCRResponse)
def patch_iucr(iucr_code: str, payload: IUCRPatch, db: Session = Depends(get_db)):
    record = db.get(IUCR, iucr_code.strip())
    if not record:
        raise HTTPException(status_code=404, detail=f"IUCR code '{iucr_code}' not found")

    if payload.primary_type is not None:
        record.primary_type = payload.primary_type.strip().upper()
    if payload.description is not None:
        record.description = payload.description.strip().upper()
    if payload.index_code is not None:
        record.index_code = payload.index_code.strip().upper() or None

    db.commit()
    db.refresh(record)
    return record


@app.delete("/iucr/{iucr_code}")
def delete_iucr(iucr_code: str, db: Session = Depends(get_db)):
    record = db.get(IUCR, iucr_code.strip())
    if not record:
        raise HTTPException(status_code=404, detail=f"IUCR code '{iucr_code}' not found")

    db.delete(record)
    db.commit()
    return {"message": f"IUCR code '{iucr_code}' deleted successfully"}