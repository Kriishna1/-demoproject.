from datetime import datetime
from typing import Optional
from sqlalchemy import Boolean, DateTime, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from backend.database import Base


class IUCR(Base):
    __tablename__ = "iucr"

    iucr_code: Mapped[str] = mapped_column(String(20), primary_key=True, index=True)
    primary_type: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    index_code: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)


class CityCommunity(Base):
    __tablename__ = "city_community"

    community_code: Mapped[int] = mapped_column(Integer, primary_key=True)
    community_name: Mapped[str] = mapped_column(String(100), nullable=False)
    population: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    area_sqmile: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    area_sqkm: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    density_per_sqmi: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    density_per_sqkm: Mapped[Optional[float]] = mapped_column(Float, nullable=True)


class ChicagoCrime(Base):
    __tablename__ = "chicago_crime"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    case_number: Mapped[str] = mapped_column(String(50), index=True)
    date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    block: Mapped[Optional[str]] = mapped_column(String(150), nullable=True)
    iucr_code: Mapped[Optional[str]] = mapped_column(String(20), index=True, nullable=True)
    location_desc: Mapped[Optional[str]] = mapped_column(String(150), nullable=True)
    arrest: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    domestic: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    beat_num: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    district_code: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    ward_no: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    community_code: Mapped[Optional[int]] = mapped_column(Integer, index=True, nullable=True)
    fbi_code: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    x_coordinate: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    y_coordinate: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    year: Mapped[Optional[int]] = mapped_column(Integer, index=True, nullable=True)
    month: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    day_of_week: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    date_of_update: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    latitude: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    longitude: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    location: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)