from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class IUCRBase(BaseModel):
    primary_type: str = Field(..., min_length=1, max_length=100)
    description: str = Field(..., min_length=1, max_length=255)
    index_code: Optional[str] = Field(default=None, max_length=10)


class IUCRCreate(IUCRBase):
    iucr_code: str = Field(..., min_length=1, max_length=20)


class IUCRUpdate(IUCRBase):
    """Used for PUT (full replacement of non-key fields)."""
    pass


class IUCRPatch(BaseModel):
    """Used for PATCH (partial update of one or more fields)."""
    primary_type: Optional[str] = Field(default=None, min_length=1, max_length=100)
    description: Optional[str] = Field(default=None, min_length=1, max_length=255)
    index_code: Optional[str] = Field(default=None, max_length=10)


class IUCRResponse(IUCRBase):
    iucr_code: str

    model_config = ConfigDict(from_attributes=True)